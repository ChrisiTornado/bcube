export interface UserResponse {
    
}