import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { LoadingSpinnerComponent } from '../../../../../shared/loading-spinner/loading-spinner.component';
import { AuthService } from '../../../../../services/auth/auth.service';
import { booking } from '../../../../../models/booking';
import { BookingService } from '../../../../../services/booking.service';
import { BookingActionService } from '../../../../../services/booking-action.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-booking-details',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    CalendarModule,
    DropdownModule,
    ButtonModule,
    LoadingSpinnerComponent
  ],
  templateUrl: './booking-details.component.html',
  styleUrl: './booking-details.component.css'
})
export class BookingDetailsComponent implements OnInit {
  isUser = false;
  booking: booking | null = null;
  loading!: boolean;
  loading$ = this.bookingService.loading$;

  ngOnInit(): void {
    this.isUser = this.authService.getRole() === 'USER';
    const studioId = this.route.snapshot.paramMap.get('id');
    if (studioId) {
      this.bookingService.getBookingById(+studioId).subscribe(data => (this.booking = data));
    }
  }

  constructor(private router: Router, private bookingActionService: BookingActionService, private authService: AuthService, private route: ActivatedRoute, private bookingService: BookingService) {

  }

  triggerStorno(): void {
    this.bookingActionService.confirmStorno(
      this.booking!,
      () => {
        const basePath = this.isUser ? '/user-dashboard' : '/admin-dashboard';
        this.router.navigate([basePath + '/bookings']);
      },
      () => {
        // optional: onError callback
      },
      (isLoading) => this.loading = isLoading
    );
  }
}
