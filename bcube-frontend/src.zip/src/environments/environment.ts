export const environment = {
    production: false,
    apiUrl: 'http://localhost:8080/api/',
    adminApiUrl: 'http://localhost:8080/api/admin/',
    authUrl: 'http://localhost:8080/api/auth/'
  };